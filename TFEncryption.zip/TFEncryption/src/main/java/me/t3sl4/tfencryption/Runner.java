package me.t3sl4.tfencryption;

import me.t3sl4.tfencryption.Main.TFEncoder;

import java.net.ServerSocket;

public class Runner extends TFEncoder {

    public static void main(String[] args) {
        TFEncoder mainApp = new TFEncoder();
        mainApp.main(args);
    }

    public static boolean checkServerSocket(ServerSocket ss) {
        if(ss == null) {
            return false;
        }
        return true;
    }
}
