package me.t3sl4.tfencryption.Utils;

public class PairOf<K, V> {
    private K first;
    private V second;

    public PairOf(K firstIn, V secondIn) {
        this.first = firstIn;
        this.second = secondIn;
    }

    public K getFirst() {
        return first;
    }

    public V getSecond() {
        return second;
    }
}
