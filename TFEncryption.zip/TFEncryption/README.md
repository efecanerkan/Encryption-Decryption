# TFEncoder
TFEncoder is a visual and bidirectional text and file encryption application using SHA256 and SPN(AES) hash and encryption algorithms on texts and files. 